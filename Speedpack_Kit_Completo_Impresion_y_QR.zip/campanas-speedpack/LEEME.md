# Kit de campañas Speedpack

Este paquete contiene seis destinos separados: PUCMM, INTEC, UNIBE, UNICARIBE, UNFU y vía pública.

Cada carpeta incluye:

- sticker para baño de 12 × 12 cm;
- flyer tamaño carta de 8.5 × 11 pulgadas;
- flyer A2 de 420 × 594 mm;
- vista previa PNG de cada pieza;
- QR general y QR individual de sticker, carta y A2 en SVG.

Los PDF tienen una sola página, dimensiones finales exactas y resolución base de 300 ppp. Imprime al 100 %, sin “ajustar a página”. Para el sticker solicita vinilo adhesivo mate, corte cuadrado 12 × 12 cm y laminado si estará expuesto a humedad. Para carta y A2 usa impresión a color con el fondo hasta el borde del papel.

Todos los QR apuntan a `https://speedpack-registro.onrender.com/`. Los códigos de campaña, fuente y pieza se registran automáticamente en Google Sheets. Los códigos pequeños al pie son de control interno y permiten relacionar impresión, instalación y resultados.

`enlaces-y-qr.csv` contiene los 24 enlaces y rutas de QR. `inventario-campanas.csv` contiene las 18 piezas imprimibles y las columnas iniciales para controlar impresión y distribución.

La mascota Speedy no aparece en ningún arte. Los canales de WhatsApp universitarios permanecen ocultos hasta cargar sus enlaces oficiales en la pestaña `Universidades` del Google Sheet.
